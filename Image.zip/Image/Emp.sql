﻿CREATE TABLE EmployeeTbl(
EmpId int primary key identity(100,1) not null,
EmpUserName varchar(50) not null,
EmpFirstName varchar(50) not null,
EmpLastName varchar(50) not null,
EmpPassword varchar(50) not null,
ImagePath varchar(500) not null
)