﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_Management_System_Project.Entities
{
    public class Employee
    {
        public int EmpId { get; set; }
        public string EmpUserName { get; set; }
        public string EmpFirstName { get; set; }
        public string EmpLastName { get; set; }
        public string EmpPassword { get; set; }
        public string ImagePath { get; set; }
        
    }
}
