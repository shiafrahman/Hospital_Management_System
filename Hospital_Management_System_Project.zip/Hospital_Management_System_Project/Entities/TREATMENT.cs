﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_Management_System_Project.Entities
{
    public class TREATMENT
    {
        public int TreatmentId { get; set; }
        public DateTime VisitDate { get; set; }
        public int PatId { get; set; }
        public int DocId { get; set; }
        public int DiagId { get; set; }
        public string Symptoms { get; set; }
        
        public decimal PaymentAmount { get; set; }
        public bool isNeededNextVisit { get; set; }
        public string ImagePath { get; set; }
    }
}
