﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_Management_System_Project.Entities
{
    public class Doctor
    {
        public int DocId { get; set; }
        public string DocName { get; set; }
        public string DocPhn { get; set; }
        public string ImagePath { get; set; }
    }
}
