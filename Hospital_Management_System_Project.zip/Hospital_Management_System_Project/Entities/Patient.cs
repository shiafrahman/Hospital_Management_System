﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_Management_System_Project.Entities
{
    public class Patient
    {
        public int PatId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public DateTime DOB { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string PatPhn { get; set; }
        public string BloodGrp { get; set; }
        public string ImgPath { get; set; }
    }
}
