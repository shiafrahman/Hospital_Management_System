﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_Management_System_Project.Entities
{
    public class TreatmentViewModel
    {
        public int TreatmentId { get; set; }
        public int PatId { get; set; }
        public int DocId { get; set; }
        public int DiagId { get; set; }
        public DateTime VisitDate { get; set; }
        public string Symptoms { get; set; }
        public decimal PaymentAmount { get; set; }
        public bool isNeededNextVisit { get; set; }
        public string FirstName { get; set; }
        public string DocName { get; set; }
        public string DiagType { get; set; }
        public string ImagePath { get; set; }
        
    }
}
