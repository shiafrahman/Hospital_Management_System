﻿using Hospital_Management_System_Project.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System_Project
{
    public partial class Report : Form
    {
        List<TreatmentViewModel> lst;
        public Report(List<TreatmentViewModel> list)
        {
            InitializeComponent();
            lst = list;
        }

        private void Report_Load(object sender, EventArgs e)
        {
            TreatmentReport objRpt = new TreatmentReport();
            objRpt.SetDataSource(lst);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }
        public Report()
        {
            InitializeComponent();
        }

        
    }
}
