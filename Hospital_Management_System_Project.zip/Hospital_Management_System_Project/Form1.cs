﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System_Project
{
    public partial class Form1 : Form
    {
        public static string userName;
        string conStr = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            userName = txtName.Text;
            string pass = txtPass.Text;
            SqlConnection con = new SqlConnection(conStr);
            string SqlQuery = "SELECT * FROM EmployeeTbl WHERE EmpUserName='" + userName + "' and EmpPassword='" + pass + "'";
            SqlCommand cmd = new SqlCommand(SqlQuery, con);
            cmd.Parameters.AddWithValue("@userName", userName);
            cmd.Parameters.AddWithValue("@pass", pass);
            con.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows == true)
            {
                
                MessageBox.Show("Login Successfull", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Home home = new Home();
                this.Hide();
                home.ShowDialog();
            }
            else
            {
                MessageBox.Show("Login Failed", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
            con.Close();

           


        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            SignUp signUp = new SignUp();
            this.Hide();
            signUp.ShowDialog();
        }

       
    }
}
