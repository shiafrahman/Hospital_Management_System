﻿using Hospital_Management_System_Project.Entities;
using Hospital_Management_System_Project.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System_Project
{
    public partial class DOCTOR : Form
    {
        string conStr = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        
        string imgName;
        string filePath = "";
        string folderPath = @"F:\ADOproject\Hospital_Management_System_ProjectSln\Hospital_Management_System_Project\Image\";
        string imagePathFromData;

       

        public DOCTOR()
        {
            InitializeComponent();
        }

        private void DOCTOR_Load(object sender, EventArgs e)
        {
            

            lblUser.Text = Form1.userName;
            LoadGridView();
            pbImageDoc.Image = Resources.noimage;
        }

        



        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlTransaction transaction;

            if (string.IsNullOrWhiteSpace(txtDocId.Text) ||
                    string.IsNullOrWhiteSpace(txtDocName.Text) ||
                    string.IsNullOrWhiteSpace(txtDocPhn.Text))
            {
                MessageBox.Show("Please fill in all the required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Doctor doc = new Doctor();
            doc.DocId= Convert.ToInt16(txtDocId.Text);
            doc.DocName = txtDocName.Text;
            doc.DocPhn = txtDocPhn.Text;
            doc.ImagePath = folderPath + Path.GetFileName(openFileDialog1.FileName);
            string sqlQuery = "Insert INTO DoctorTbl VALUES (@DocId,@DocName,@DocPhn,@ImagePath)";
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            if (filePath == "")
            {
                //cmd.Parameters.AddWithValue("@ImagePath", "No Image Found");
                MessageBox.Show("Please select an image.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ImagePath", doc.ImagePath);
                try
                {
                    File.Copy(filePath, Path.Combine(folderPath, Path.GetFileName(filePath)), true);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            cmd.Parameters.AddWithValue("@DocId", doc.DocId);
            cmd.Parameters.AddWithValue("@DocName", doc.DocName);
            cmd.Parameters.AddWithValue("@DocPhn", doc.DocPhn);

            con.Open();
            transaction = con.BeginTransaction();
            cmd.Transaction = transaction;
            int rowCount = cmd.ExecuteNonQuery();
            if (rowCount > 0)
            {
                transaction.Commit();
                MessageBox.Show("Doctor added successfully!", "Success", MessageBoxButtons.OK);
                ClearMethod();
                
            }
            else
            {
                MessageBox.Show("Doctor Insertion failed!", "Failure", MessageBoxButtons.OK);
                ClearMethod();
                transaction.Rollback();
            }
            con.Close();
            LoadGridView();
            ClearMethod();
        }

        private void LoadGridView()
        {
            ShowImageInGridView();
        }

        private void ShowImageInGridView()
        {
            string sqlQuery = "SELECT DocId,DocName,DocPhn,ImagePath FROM DoctorTbl";
            SqlConnection con = new SqlConnection(conStr);
            SqlDataAdapter sda = new SqlDataAdapter(sqlQuery, con);
            DataTable dt = new DataTable();
            con.Open();
            sda.Fill(dt);
            dt.Columns.Add("Picture", Type.GetType("System.Byte[]"));
            foreach (DataRow dr in dt.Rows)
            {
                try
                {
                    dr["Picture"] = File.ReadAllBytes(dr["ImagePath"].ToString());
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            con.Close();
            dgvDoctor.RowTemplate.Height = 52;
            dgvDoctor.DataSource = dt;
            DataGridViewImageColumn dgvImage = new DataGridViewImageColumn();
            dgvImage = (DataGridViewImageColumn)dgvDoctor.Columns[4];
            dgvImage.ImageLayout = DataGridViewImageCellLayout.Stretch;
            dgvDoctor.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        }

        private void ClearMethod()
        {
            txtDocId.Text = "";
            txtDocName.Text = "";
            txtDocPhn.Text = "";
            pbImageDoc.Image = Resources.noimage;
            
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image File(*.jpg; *.png; *.jpeg; *.gif; *.bmp)| *.jpg; *.png; *.jpeg; *.gif; *.bmp|all files|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                imgName = openFileDialog1.SafeFileName;
                pbImageDoc.Image = new Bitmap(openFileDialog1.FileName);
                filePath = openFileDialog1.FileName;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearMethod();
        }

        private void dgvDoctor_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            int cellId = e.RowIndex;
            try
            {
                DataGridViewRow row = dgvDoctor.Rows[cellId];
                txtDocId.Text = row.Cells[0].Value.ToString();
                txtDocName.Text = row.Cells[1].Value.ToString();
                txtDocPhn.Text = row.Cells[2].Value.ToString();
                
                if (imagePathFromData == "No Image")
                {
                    pbImageDoc.Image = Resources.noimage;
                }
                byte[] data = (byte[])row.Cells[4].Value;
                MemoryStream stream = new MemoryStream(data);
                pbImageDoc.Image = Image.FromStream(stream);
                imagePathFromData = row.Cells[3].Value.ToString();
            }
            catch (Exception)
            {

                throw;
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlTransaction transaction;

            if (!string.IsNullOrEmpty(txtDocId.Text))
            {
                Doctor doc = new Doctor();
                doc.DocId = Convert.ToInt16(txtDocId.Text);
                doc.DocName = txtDocName.Text;
                doc.DocPhn = txtDocPhn.Text;
                doc.ImagePath = folderPath + Path.GetFileName(openFileDialog1.FileName);
                string sqlQuery = "UPDATE DoctorTbl SET DocName=@DocName,DocPhn=@DocPhn,ImagePath=@ImagePath WHERE DocId=@DocId";
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                if (filePath == "")
                {
                    cmd.Parameters.AddWithValue("@ImagePath", imagePathFromData);
                }
                else
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@ImagePath", doc.ImagePath);
                    try
                    {
                        File.Copy(filePath, Path.Combine(folderPath, Path.GetFileName(filePath)), true);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                cmd.Parameters.AddWithValue("@DocId", doc.DocId);
                cmd.Parameters.AddWithValue("@DocName", doc.DocName);
                cmd.Parameters.AddWithValue("@DocPhn", doc.DocPhn);
                con.Open();
                transaction = con.BeginTransaction();
                cmd.Transaction = transaction;
                int rowCount = cmd.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    transaction.Commit();
                    MessageBox.Show("Doctor updated successfully!", "Success", MessageBoxButtons.OK);
                    ClearMethod();
                    
                }
                else
                {
                    MessageBox.Show("Doctor updation failed!", "Failure", MessageBoxButtons.OK);
                    ClearMethod();
                    transaction.Rollback();
                }
                con.Close();
                LoadGridView();
                ClearMethod();
            }
            else
            {
                MessageBox.Show("Please select Doctor Id!", "Warning", MessageBoxButtons.OK);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlTransaction transaction;

            if (!string.IsNullOrEmpty(txtDocId.Text))
            {
                Doctor doc = new Doctor();
                doc.DocId = Convert.ToInt16(txtDocId.Text);
                string sqlQuery = "DELETE FROM  DoctorTbl WHERE DocId=@DocId";
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.Parameters.AddWithValue("@DocId", doc.DocId);
                con.Open();
                transaction = con.BeginTransaction();
                cmd.Transaction = transaction;
                int rowCount = cmd.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    transaction.Commit();
                    MessageBox.Show("Deleted successfully!", "Success", MessageBoxButtons.OK);
                    ClearMethod();
                    
                }
                else
                {
                    MessageBox.Show("Deletion failed!", "Failure", MessageBoxButtons.OK);
                    ClearMethod();
                    transaction.Rollback();
                }
                con.Close();
                LoadGridView();
                ClearMethod();
            }
            else
            {
                MessageBox.Show("Please select Doctor Id!", "Warning", MessageBoxButtons.OK);
            }
        }

        private void pBback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home doc = new Home();
            doc.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            ProjectLoading p = new ProjectLoading();
            p.ShowDialog();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.Hide();
            PATIENT t = new PATIENT();
            t.ShowDialog();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            this.Hide();
            TreatMenet t = new TreatMenet();
            t.ShowDialog();
        }
    }
}
