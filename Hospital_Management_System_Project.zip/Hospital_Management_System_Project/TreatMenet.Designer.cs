﻿namespace Hospital_Management_System_Project
{
    partial class TreatMenet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TreatMenet));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblUser = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.radYes = new System.Windows.Forms.RadioButton();
            this.radNo = new System.Windows.Forms.RadioButton();
            this.txtPayment = new System.Windows.Forms.TextBox();
            this.cmbDocName = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.cmbPatName = new System.Windows.Forms.ComboBox();
            this.btnTrmBrowse = new System.Windows.Forms.Button();
            this.pbTreatment = new System.Windows.Forms.PictureBox();
            this.lblPatientDOB = new System.Windows.Forms.Label();
            this.dtpVisitDate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.lblPatientGender = new System.Windows.Forms.Label();
            this.lblPatientAge = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lalPLName = new System.Windows.Forms.Label();
            this.txtSym = new System.Windows.Forms.TextBox();
            this.lblPatientFName = new System.Windows.Forms.Label();
            this.lblPatientId = new System.Windows.Forms.Label();
            this.txtTreatmentId = new System.Windows.Forms.TextBox();
            this.btnPatClear = new System.Windows.Forms.Button();
            this.btnDelete1 = new System.Windows.Forms.Button();
            this.btnUpdate1 = new System.Windows.Forms.Button();
            this.btnAdd1 = new System.Windows.Forms.Button();
            this.dgvTreatment = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbDiagnosis = new System.Windows.Forms.ComboBox();
            this.btnReport = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnAddDiagnosis = new System.Windows.Forms.Button();
            this.txtDiag = new System.Windows.Forms.TextBox();
            this.lblProduct = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTreatment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTreatment)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.lblUser);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1539, 92);
            this.panel1.TabIndex = 24;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1485, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(53, 28);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lblUser
            // 
            this.lblUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Britannic Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.ForeColor = System.Drawing.Color.White;
            this.lblUser.Location = new System.Drawing.Point(1358, 33);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(113, 26);
            this.lblUser.TabIndex = 1;
            this.lblUser.Text = "Username";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bahnschrift Condensed", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label8.Location = new System.Drawing.Point(23, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(160, 45);
            this.label8.TabIndex = 0;
            this.label8.Text = "TREATMENT";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label9.Location = new System.Drawing.Point(12, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(206, 24);
            this.label9.TabIndex = 0;
            this.label9.Text = "Hospital Management System";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // radYes
            // 
            this.radYes.AutoSize = true;
            this.radYes.BackColor = System.Drawing.Color.Transparent;
            this.radYes.Font = new System.Drawing.Font("Bahnschrift SemiBold", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radYes.ForeColor = System.Drawing.Color.Black;
            this.radYes.Location = new System.Drawing.Point(170, 504);
            this.radYes.Name = "radYes";
            this.radYes.Size = new System.Drawing.Size(79, 38);
            this.radYes.TabIndex = 114;
            this.radYes.TabStop = true;
            this.radYes.Text = "Yes";
            this.radYes.UseVisualStyleBackColor = false;
            // 
            // radNo
            // 
            this.radNo.AutoSize = true;
            this.radNo.Font = new System.Drawing.Font("Bahnschrift SemiBold", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radNo.ForeColor = System.Drawing.Color.Black;
            this.radNo.Location = new System.Drawing.Point(253, 504);
            this.radNo.Name = "radNo";
            this.radNo.Size = new System.Drawing.Size(71, 38);
            this.radNo.TabIndex = 113;
            this.radNo.TabStop = true;
            this.radNo.Text = "No";
            this.radNo.UseVisualStyleBackColor = true;
            // 
            // txtPayment
            // 
            this.txtPayment.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayment.Location = new System.Drawing.Point(168, 464);
            this.txtPayment.Multiline = true;
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.Size = new System.Drawing.Size(239, 34);
            this.txtPayment.TabIndex = 112;
            // 
            // cmbDocName
            // 
            this.cmbDocName.BackColor = System.Drawing.Color.White;
            this.cmbDocName.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDocName.ForeColor = System.Drawing.Color.Black;
            this.cmbDocName.FormattingEnabled = true;
            this.cmbDocName.Location = new System.Drawing.Point(170, 327);
            this.cmbDocName.Name = "cmbDocName";
            this.cmbDocName.Size = new System.Drawing.Size(238, 36);
            this.cmbDocName.TabIndex = 111;
            this.cmbDocName.Text = "Select Doctor";
            // 
            // comboBox2
            // 
            this.comboBox2.BackColor = System.Drawing.Color.White;
            this.comboBox2.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.ForeColor = System.Drawing.Color.Black;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(169, 328);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(238, 36);
            this.comboBox2.TabIndex = 110;
            // 
            // cmbPatName
            // 
            this.cmbPatName.BackColor = System.Drawing.Color.White;
            this.cmbPatName.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPatName.ForeColor = System.Drawing.Color.Black;
            this.cmbPatName.FormattingEnabled = true;
            this.cmbPatName.Location = new System.Drawing.Point(169, 286);
            this.cmbPatName.Name = "cmbPatName";
            this.cmbPatName.Size = new System.Drawing.Size(238, 36);
            this.cmbPatName.TabIndex = 109;
            this.cmbPatName.Text = "Select Patient";
            // 
            // btnTrmBrowse
            // 
            this.btnTrmBrowse.BackColor = System.Drawing.Color.Transparent;
            this.btnTrmBrowse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTrmBrowse.Font = new System.Drawing.Font("Berlin Sans FB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrmBrowse.ForeColor = System.Drawing.Color.DimGray;
            this.btnTrmBrowse.Location = new System.Drawing.Point(170, 150);
            this.btnTrmBrowse.Name = "btnTrmBrowse";
            this.btnTrmBrowse.Size = new System.Drawing.Size(111, 40);
            this.btnTrmBrowse.TabIndex = 108;
            this.btnTrmBrowse.Text = "Browse";
            this.btnTrmBrowse.UseVisualStyleBackColor = false;
            this.btnTrmBrowse.Click += new System.EventHandler(this.btnTrmBrowse_Click);
            // 
            // pbTreatment
            // 
            this.pbTreatment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbTreatment.Location = new System.Drawing.Point(303, 22);
            this.pbTreatment.Name = "pbTreatment";
            this.pbTreatment.Size = new System.Drawing.Size(187, 168);
            this.pbTreatment.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbTreatment.TabIndex = 107;
            this.pbTreatment.TabStop = false;
            // 
            // lblPatientDOB
            // 
            this.lblPatientDOB.AutoSize = true;
            this.lblPatientDOB.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientDOB.ForeColor = System.Drawing.Color.Black;
            this.lblPatientDOB.Location = new System.Drawing.Point(37, 370);
            this.lblPatientDOB.Name = "lblPatientDOB";
            this.lblPatientDOB.Size = new System.Drawing.Size(124, 34);
            this.lblPatientDOB.TabIndex = 106;
            this.lblPatientDOB.Text = "Symptoms :";
            // 
            // dtpVisitDate
            // 
            this.dtpVisitDate.CalendarFont = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpVisitDate.CalendarTitleBackColor = System.Drawing.Color.Snow;
            this.dtpVisitDate.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpVisitDate.Location = new System.Drawing.Point(172, 246);
            this.dtpVisitDate.Name = "dtpVisitDate";
            this.dtpVisitDate.Size = new System.Drawing.Size(236, 27);
            this.dtpVisitDate.TabIndex = 105;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(47, 417);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 34);
            this.label4.TabIndex = 104;
            this.label4.Text = "Diagnosis :";
            // 
            // lblPatientGender
            // 
            this.lblPatientGender.AutoSize = true;
            this.lblPatientGender.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientGender.ForeColor = System.Drawing.Color.Black;
            this.lblPatientGender.Location = new System.Drawing.Point(46, 417);
            this.lblPatientGender.Name = "lblPatientGender";
            this.lblPatientGender.Size = new System.Drawing.Size(115, 34);
            this.lblPatientGender.TabIndex = 103;
            this.lblPatientGender.Text = "Diagnosis :";
            // 
            // lblPatientAge
            // 
            this.lblPatientAge.AutoSize = true;
            this.lblPatientAge.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientAge.ForeColor = System.Drawing.Color.Black;
            this.lblPatientAge.Location = new System.Drawing.Point(16, 327);
            this.lblPatientAge.Name = "lblPatientAge";
            this.lblPatientAge.Size = new System.Drawing.Size(145, 34);
            this.lblPatientAge.TabIndex = 102;
            this.lblPatientAge.Text = "Doctor Name :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(42, 504);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 34);
            this.label6.TabIndex = 101;
            this.label6.Text = "Next Visit :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(50, 461);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 34);
            this.label5.TabIndex = 100;
            this.label5.Text = "Payment :";
            // 
            // lalPLName
            // 
            this.lalPLName.AutoSize = true;
            this.lalPLName.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lalPLName.ForeColor = System.Drawing.Color.Black;
            this.lalPLName.Location = new System.Drawing.Point(14, 285);
            this.lalPLName.Name = "lalPLName";
            this.lalPLName.Size = new System.Drawing.Size(149, 34);
            this.lalPLName.TabIndex = 99;
            this.lalPLName.Text = "Patient Name :";
            // 
            // txtSym
            // 
            this.txtSym.BackColor = System.Drawing.Color.White;
            this.txtSym.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSym.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSym.ForeColor = System.Drawing.Color.Black;
            this.txtSym.Location = new System.Drawing.Point(170, 374);
            this.txtSym.Multiline = true;
            this.txtSym.Name = "txtSym";
            this.txtSym.Size = new System.Drawing.Size(238, 30);
            this.txtSym.TabIndex = 96;
            // 
            // lblPatientFName
            // 
            this.lblPatientFName.AutoSize = true;
            this.lblPatientFName.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientFName.ForeColor = System.Drawing.Color.Black;
            this.lblPatientFName.Location = new System.Drawing.Point(48, 239);
            this.lblPatientFName.Name = "lblPatientFName";
            this.lblPatientFName.Size = new System.Drawing.Size(113, 34);
            this.lblPatientFName.TabIndex = 98;
            this.lblPatientFName.Text = "Visit Date :";
            // 
            // lblPatientId
            // 
            this.lblPatientId.AutoSize = true;
            this.lblPatientId.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientId.ForeColor = System.Drawing.Color.Black;
            this.lblPatientId.Location = new System.Drawing.Point(18, 203);
            this.lblPatientId.Name = "lblPatientId";
            this.lblPatientId.Size = new System.Drawing.Size(143, 34);
            this.lblPatientId.TabIndex = 94;
            this.lblPatientId.Text = "Treatment Id :";
            // 
            // txtTreatmentId
            // 
            this.txtTreatmentId.BackColor = System.Drawing.Color.White;
            this.txtTreatmentId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTreatmentId.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTreatmentId.ForeColor = System.Drawing.Color.Black;
            this.txtTreatmentId.Location = new System.Drawing.Point(169, 207);
            this.txtTreatmentId.Multiline = true;
            this.txtTreatmentId.Name = "txtTreatmentId";
            this.txtTreatmentId.Size = new System.Drawing.Size(236, 30);
            this.txtTreatmentId.TabIndex = 93;
            // 
            // btnPatClear
            // 
            this.btnPatClear.BackColor = System.Drawing.Color.Transparent;
            this.btnPatClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPatClear.Font = new System.Drawing.Font("Berlin Sans FB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPatClear.ForeColor = System.Drawing.Color.DimGray;
            this.btnPatClear.Location = new System.Drawing.Point(383, 548);
            this.btnPatClear.Name = "btnPatClear";
            this.btnPatClear.Size = new System.Drawing.Size(97, 51);
            this.btnPatClear.TabIndex = 118;
            this.btnPatClear.Text = "Clear";
            this.btnPatClear.UseVisualStyleBackColor = false;
            this.btnPatClear.Click += new System.EventHandler(this.btnPatClear_Click);
            // 
            // btnDelete1
            // 
            this.btnDelete1.BackColor = System.Drawing.Color.Transparent;
            this.btnDelete1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete1.Font = new System.Drawing.Font("Berlin Sans FB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete1.ForeColor = System.Drawing.Color.DimGray;
            this.btnDelete1.Location = new System.Drawing.Point(268, 548);
            this.btnDelete1.Name = "btnDelete1";
            this.btnDelete1.Size = new System.Drawing.Size(109, 51);
            this.btnDelete1.TabIndex = 117;
            this.btnDelete1.Text = "Delete";
            this.btnDelete1.UseVisualStyleBackColor = false;
            this.btnDelete1.Click += new System.EventHandler(this.btnDelete1_Click);
            // 
            // btnUpdate1
            // 
            this.btnUpdate1.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdate1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate1.Font = new System.Drawing.Font("Berlin Sans FB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate1.ForeColor = System.Drawing.Color.DimGray;
            this.btnUpdate1.Location = new System.Drawing.Point(144, 548);
            this.btnUpdate1.Name = "btnUpdate1";
            this.btnUpdate1.Size = new System.Drawing.Size(118, 51);
            this.btnUpdate1.TabIndex = 116;
            this.btnUpdate1.Text = "Update";
            this.btnUpdate1.UseVisualStyleBackColor = false;
            this.btnUpdate1.Click += new System.EventHandler(this.btnUpdate1_Click);
            // 
            // btnAdd1
            // 
            this.btnAdd1.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd1.Font = new System.Drawing.Font("Berlin Sans FB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd1.ForeColor = System.Drawing.Color.DimGray;
            this.btnAdd1.Location = new System.Drawing.Point(23, 548);
            this.btnAdd1.Name = "btnAdd1";
            this.btnAdd1.Size = new System.Drawing.Size(115, 51);
            this.btnAdd1.TabIndex = 115;
            this.btnAdd1.Text = "Add";
            this.btnAdd1.UseVisualStyleBackColor = false;
            this.btnAdd1.Click += new System.EventHandler(this.btnAdd1_Click);
            // 
            // dgvTreatment
            // 
            this.dgvTreatment.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTreatment.BackgroundColor = System.Drawing.Color.White;
            this.dgvTreatment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTreatment.Location = new System.Drawing.Point(574, 204);
            this.dgvTreatment.Name = "dgvTreatment";
            this.dgvTreatment.RowHeadersWidth = 51;
            this.dgvTreatment.RowTemplate.Height = 24;
            this.dgvTreatment.Size = new System.Drawing.Size(939, 431);
            this.dgvTreatment.TabIndex = 119;
            this.dgvTreatment.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTreatment_CellClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(941, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(232, 36);
            this.label3.TabIndex = 120;
            this.label3.Text = "TREATMENT TABLE";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbDiagnosis);
            this.groupBox1.Controls.Add(this.pbTreatment);
            this.groupBox1.Controls.Add(this.btnTrmBrowse);
            this.groupBox1.Controls.Add(this.lblPatientId);
            this.groupBox1.Controls.Add(this.btnPatClear);
            this.groupBox1.Controls.Add(this.txtTreatmentId);
            this.groupBox1.Controls.Add(this.btnDelete1);
            this.groupBox1.Controls.Add(this.btnUpdate1);
            this.groupBox1.Controls.Add(this.lblPatientFName);
            this.groupBox1.Controls.Add(this.btnAdd1);
            this.groupBox1.Controls.Add(this.txtSym);
            this.groupBox1.Controls.Add(this.radYes);
            this.groupBox1.Controls.Add(this.radNo);
            this.groupBox1.Controls.Add(this.lalPLName);
            this.groupBox1.Controls.Add(this.txtPayment);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cmbDocName);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.lblPatientAge);
            this.groupBox1.Controls.Add(this.cmbPatName);
            this.groupBox1.Controls.Add(this.lblPatientGender);
            this.groupBox1.Controls.Add(this.lblPatientDOB);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.dtpVisitDate);
            this.groupBox1.Font = new System.Drawing.Font("Bahnschrift", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(16, 113);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(514, 611);
            this.groupBox1.TabIndex = 121;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Treatment Form";
            // 
            // cmbDiagnosis
            // 
            this.cmbDiagnosis.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDiagnosis.FormattingEnabled = true;
            this.cmbDiagnosis.Location = new System.Drawing.Point(170, 414);
            this.cmbDiagnosis.Name = "cmbDiagnosis";
            this.cmbDiagnosis.Size = new System.Drawing.Size(237, 36);
            this.cmbDiagnosis.TabIndex = 119;
            // 
            // btnReport
            // 
            this.btnReport.Location = new System.Drawing.Point(1339, 113);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(110, 33);
            this.btnReport.TabIndex = 122;
            this.btnReport.Text = "View Report";
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnAddDiagnosis);
            this.groupBox2.Controls.Add(this.txtDiag);
            this.groupBox2.Controls.Add(this.lblProduct);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(574, 662);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(371, 62);
            this.groupBox2.TabIndex = 123;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Diagnosis";
            // 
            // btnAddDiagnosis
            // 
            this.btnAddDiagnosis.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddDiagnosis.Location = new System.Drawing.Point(249, 19);
            this.btnAddDiagnosis.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddDiagnosis.Name = "btnAddDiagnosis";
            this.btnAddDiagnosis.Size = new System.Drawing.Size(100, 28);
            this.btnAddDiagnosis.TabIndex = 2;
            this.btnAddDiagnosis.Text = "Add";
            this.btnAddDiagnosis.UseVisualStyleBackColor = true;
            this.btnAddDiagnosis.Click += new System.EventHandler(this.btnAddDiagnosis_Click);
            // 
            // txtDiag
            // 
            this.txtDiag.Location = new System.Drawing.Point(96, 22);
            this.txtDiag.Margin = new System.Windows.Forms.Padding(4);
            this.txtDiag.Name = "txtDiag";
            this.txtDiag.Size = new System.Drawing.Size(145, 23);
            this.txtDiag.TabIndex = 1;
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Location = new System.Drawing.Point(9, 25);
            this.lblProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(79, 17);
            this.lblProduct.TabIndex = 0;
            this.lblProduct.Text = "Diagnosis";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Britannic Bold", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(878, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 22);
            this.label1.TabIndex = 23;
            this.label1.Text = "Add Doctor";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Britannic Bold", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(1013, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 22);
            this.label2.TabIndex = 24;
            this.label2.Text = "Add Patient";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Britannic Bold", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(786, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 22);
            this.label7.TabIndex = 25;
            this.label7.Text = "Home";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // TreatMenet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumTurquoise;
            this.ClientSize = new System.Drawing.Size(1539, 736);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnReport);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgvTreatment);
            this.Controls.Add(this.panel1);
            this.Name = "TreatMenet";
            this.Text = "TreatMenet";
            this.Load += new System.EventHandler(this.TreatMenet_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTreatment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTreatment)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton radYes;
        private System.Windows.Forms.RadioButton radNo;
        private System.Windows.Forms.TextBox txtPayment;
        private System.Windows.Forms.ComboBox cmbDocName;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox cmbPatName;
        private System.Windows.Forms.Button btnTrmBrowse;
        private System.Windows.Forms.PictureBox pbTreatment;
        private System.Windows.Forms.Label lblPatientDOB;
        private System.Windows.Forms.DateTimePicker dtpVisitDate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblPatientGender;
        private System.Windows.Forms.Label lblPatientAge;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lalPLName;
        private System.Windows.Forms.TextBox txtSym;
        private System.Windows.Forms.Label lblPatientFName;
        private System.Windows.Forms.Label lblPatientId;
        private System.Windows.Forms.TextBox txtTreatmentId;
        private System.Windows.Forms.Button btnPatClear;
        private System.Windows.Forms.Button btnDelete1;
        private System.Windows.Forms.Button btnUpdate1;
        private System.Windows.Forms.Button btnAdd1;
        private System.Windows.Forms.DataGridView dgvTreatment;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.ComboBox cmbDiagnosis;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnAddDiagnosis;
        private System.Windows.Forms.TextBox txtDiag;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
    }
}