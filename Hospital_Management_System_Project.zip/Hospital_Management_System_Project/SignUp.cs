﻿using Hospital_Management_System_Project.Entities;
using Hospital_Management_System_Project.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System_Project
{
    public partial class SignUp : Form
    {
        Employee objEmployee = new Employee();
        string conStr = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        string  imgName;
        string filePath = "";
        string folderPath = @"F:\ADOproject\Hospital_Management_System_ProjectSln\Hospital_Management_System_Project\Image\";
        string imagePathFromData;
        public SignUp()
        {
            InitializeComponent();
            
        }

        private void SignUp_Load(object sender, EventArgs e)
        {
            pbImageEmployee.Image = Resources.noimage;
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtUsername.Text) ||
                    string.IsNullOrWhiteSpace(txtFirstName.Text) ||
                    string.IsNullOrWhiteSpace(txtLastName.Text) ||
                    string.IsNullOrWhiteSpace(txtPass.Text))
                {
                    MessageBox.Show("Please fill in all the required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }          
                objEmployee.EmpUserName = txtUsername.Text;
                objEmployee.EmpFirstName = txtFirstName.Text;
                objEmployee.EmpLastName = txtLastName.Text;
                objEmployee.EmpPassword = txtPass.Text;
                objEmployee.ImagePath = folderPath + Path.GetFileName(openFileDialog1.FileName); ;
                SqlConnection con = new SqlConnection(conStr);
                string SqlQuery = "Insert into EmployeeTbl values(@EmpUserName,@EmpFirstName,@EmpLastName,@EmpPassword,@ImagePath)";
                SqlCommand cmd = new SqlCommand(SqlQuery, con);
                if (filePath == "")
                {
                    //cmd.Parameters.AddWithValue("@ImagePath", "No Image Found");
                    MessageBox.Show("Please select an image.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@ImagePath", objEmployee.ImagePath);
                    try
                    {
                        File.Copy(filePath, Path.Combine(folderPath, Path.GetFileName(filePath)), true);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                cmd.Parameters.AddWithValue("@EmpUserName", objEmployee.EmpUserName);
                cmd.Parameters.AddWithValue("@EmpFirstName", objEmployee.EmpFirstName);
                cmd.Parameters.AddWithValue("@EmpLastName", objEmployee.EmpLastName);
                cmd.Parameters.AddWithValue("@EmpPassword", objEmployee.EmpPassword);
                //cmd.Parameters.AddWithValue("@ImagePath", objEmployee.ImagePath);
                con.Open();
                int rowCount = cmd.ExecuteNonQuery();
               // con.Close();
                if (rowCount > 0)
                {
                    MessageBox.Show("Account Created Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                }
                else
                {
                    MessageBox.Show("Failed to create Account", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            //OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Image File(*.jpg; *.png; *.jpeg; *.gif; *.bmp)| *.jpg; *.png; *.jpeg; *.gif; *.bmp|all files|*.*";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                imgName = openFileDialog1.SafeFileName;
                pbImageEmployee.Image = new Bitmap(openFileDialog1.FileName);
                filePath = openFileDialog1.FileName;
                //imageLocation = openFileDialog1.FileName.ToString();
                //pbImageEmployee.Image = new Bitmap(openFileDialog1.FileName);
            }
        }

        private void pBback_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            this.Hide();
            login.ShowDialog();
        }
    }
}
