﻿using Hospital_Management_System_Project.Entities;
using Hospital_Management_System_Project.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System_Project
{
    public partial class PATIENT : Form
    {

        string conStr = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        
        string imgName;
        string filePath = "";
        string folderPath = @"F:\ADOproject\Hospital_Management_System_ProjectSln\Hospital_Management_System_Project\Image\";
        string imagePathFromData;
        public PATIENT()
        {
            InitializeComponent();
        }

        private void PATIENT_Load(object sender, EventArgs e)
        {
            lblUser.Text = Form1.userName;
            LoadGridView();
            pbPatient.Image = Resources.noimage3;
        }

       

        private void btnAdd1_Click(object sender, EventArgs e)
        {
            SqlTransaction transaction;
            if (string.IsNullOrWhiteSpace(textPatientId.Text) || string.IsNullOrWhiteSpace(txtPatientFName.Text) || string.IsNullOrWhiteSpace(cmbPatientGender.Text) || string.IsNullOrWhiteSpace(txtPatientAddress.Text) || string.IsNullOrWhiteSpace(txtPhnNo.Text) || string.IsNullOrWhiteSpace(cmbBloodGroup.Text))
            {
                MessageBox.Show("Please fill in all the required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Patient pat = new Patient();
            pat.PatId = Convert.ToInt16(textPatientId.Text);
            pat.FirstName= txtPatientFName.Text;
            pat.LastName = txtPatientLName.Text;
            pat.Age = Convert.ToInt16(txtPatAge.Text);
            pat.DOB = Convert.ToDateTime(dtpDOB.Text);
            pat.Gender = cmbPatientGender.Text;
            pat.Address = txtPatientAddress.Text;
            pat.PatPhn = txtPhnNo.Text;
            pat.BloodGrp = cmbBloodGroup.Text;
            pat.ImgPath = folderPath + Path.GetFileName(openFileDialog1.FileName);
            string sqlQuery = "Insert INTO PatientTbl VALUES (@PatId,@FirstName, @LastName,@Age,@DOB,@Gender,@Address,@PatPhn,@BloodGrp,@ImgPath)";
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            if (filePath == "")
            {
                //cmd.Parameters.AddWithValue("@ImgPath", "No Image Found");
                MessageBox.Show("Please select an image.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ImgPath", pat.ImgPath);
                try
                {
                    File.Copy(filePath, Path.Combine(folderPath, Path.GetFileName(filePath)), true);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            cmd.Parameters.AddWithValue("@PatId", pat.PatId);
            cmd.Parameters.AddWithValue("@FirstName", pat.FirstName);
            cmd.Parameters.AddWithValue("@LastName", pat.LastName);
            cmd.Parameters.AddWithValue("@Age", pat.Age);
            cmd.Parameters.AddWithValue("@DOB", pat.DOB);
            cmd.Parameters.AddWithValue("@Gender", pat.Gender);
            cmd.Parameters.AddWithValue("@Address", pat.Address);
            cmd.Parameters.AddWithValue("@PatPhn", pat.PatPhn);
            cmd.Parameters.AddWithValue("@BloodGrp", pat.BloodGrp);
            con.Open();
            transaction = con.BeginTransaction();
            cmd.Transaction = transaction;
            int rowCount = cmd.ExecuteNonQuery();
            if (rowCount > 0)
            {
                transaction.Commit();
                MessageBox.Show("Patient added successfully!", "Success", MessageBoxButtons.OK);
                ClearMethod();
                
            }
            else
            {
                MessageBox.Show("Patient Insertion failed!", "Failure", MessageBoxButtons.OK);
                ClearMethod();
                transaction.Rollback();
            }
            con.Close();
            LoadGridView();
            ClearMethod();

        }

        private void LoadGridView()
        {
            ShowImageInGridView();
        }

        

        private void btnPatBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image File(*.jpg; *.png; *.jpeg; *.gif; *.bmp)| *.jpg; *.png; *.jpeg; *.gif; *.bmp|all files|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                imgName = openFileDialog1.SafeFileName;
                pbPatient.Image = new Bitmap(openFileDialog1.FileName);
                filePath = openFileDialog1.FileName;
            }
        }

        private void btnPatClear_Click(object sender, EventArgs e)
        {
            ClearMethod();
        }

        private void ClearMethod()
        {
            textPatientId.Text = "";
            txtPatientFName.Text = "";
            txtPatientLName.Text = "";
            txtPatAge.Text = "";
            dtpDOB.Text = "";
            cmbPatientGender.Text = "";
            txtPatientAddress.Text = "";
            txtPhnNo.Text = "";
            cmbBloodGroup.Text = "";
            pbPatient.Image = Resources.noimage3;
        }

        private void ShowImageInGridView()
        {
            string sqlQuery = "SELECT PatId,FirstName,LastName, Age, DOB, Gender, Address, PatPhn,BloodGrp,ImgPath FROM PatientTbl";
            SqlConnection con = new SqlConnection(conStr);
            SqlDataAdapter sda = new SqlDataAdapter(sqlQuery, con);
            DataTable dt = new DataTable();
            con.Open();
            sda.Fill(dt);
            dt.Columns.Add("Picture", Type.GetType("System.Byte[]"));
            foreach (DataRow dr in dt.Rows)
            {
                try
                {
                    dr["Picture"] = File.ReadAllBytes(dr["ImgPath"].ToString());
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            con.Close();
            dgvParient.RowTemplate.Height = 52;
            dgvParient.DataSource = dt;
            DataGridViewImageColumn dgvImage = new DataGridViewImageColumn();
            dgvImage = (DataGridViewImageColumn)dgvParient.Columns[10];
            dgvImage.ImageLayout = DataGridViewImageCellLayout.Stretch;
            dgvParient.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void dgvParient_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int cellId = e.RowIndex;
            try
            {
                DataGridViewRow row = dgvParient.Rows[cellId];
                textPatientId.Text = row.Cells[0].Value.ToString();
                txtPatientFName.Text = row.Cells[1].Value.ToString();
                txtPatientLName.Text = row.Cells[2].Value.ToString();
                txtPatAge.Text = row.Cells[3].Value.ToString();
                dtpDOB.Text = row.Cells[4].Value.ToString();
                cmbPatientGender.Text = row.Cells[5].Value.ToString();
                
                txtPatientAddress.Text = row.Cells[6].Value.ToString();
                txtPhnNo.Text = row.Cells[7].Value.ToString();
                cmbBloodGroup.Text = row.Cells[8].Value.ToString();
                if (imagePathFromData == "No Image")
                {
                    pbPatient.Image = Resources.noimage3;
                }
                byte[] data = (byte[])row.Cells[10].Value;
                MemoryStream stream = new MemoryStream(data);
                pbPatient.Image = Image.FromStream(stream);
                imagePathFromData = row.Cells[9].Value.ToString();
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnUpdate1_Click(object sender, EventArgs e)
        {
            SqlTransaction transaction;

            if (!string.IsNullOrEmpty(textPatientId.Text))
            {
                Patient pat = new Patient();
                pat.PatId = Convert.ToInt16(textPatientId.Text);
                pat.FirstName = txtPatientFName.Text;
                pat.LastName = txtPatientLName.Text;
                pat.Age = Convert.ToInt16(txtPatAge.Text);
                pat.DOB = Convert.ToDateTime(dtpDOB.Text);
                pat.Gender = cmbPatientGender.Text;
                pat.Address = txtPatientAddress.Text;
                pat.PatPhn = txtPhnNo.Text;
                pat.BloodGrp = cmbBloodGroup.Text;
                pat.ImgPath = folderPath + Path.GetFileName(openFileDialog1.FileName);
                string sqlQuery = "UPDATE PatientTbl SET FirstName=@FirstName, LastName=@LastName,Age=@Age,DOB=@DOB,Gender=@Gender,Address=@Address,PatPhn=@PatPhn,BloodGrp=@BloodGrp,ImgPath=@ImgPath WHERE PatId=@PatId";
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                if (filePath == "")
                {
                    cmd.Parameters.AddWithValue("@ImgPath", imagePathFromData);
                }
                else
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@ImgPath", pat.ImgPath);
                    try
                    {
                        File.Copy(filePath, Path.Combine(folderPath, Path.GetFileName(filePath)), true);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                cmd.Parameters.AddWithValue("@PatId", pat.PatId);
                cmd.Parameters.AddWithValue("@FirstName", pat.FirstName);
                cmd.Parameters.AddWithValue("@LastName", pat.LastName);
                cmd.Parameters.AddWithValue("@Age", pat.Age);
                cmd.Parameters.AddWithValue("@DOB", pat.DOB);
                cmd.Parameters.AddWithValue("@Gender", pat.Gender);
                cmd.Parameters.AddWithValue("@Address", pat.Address);
                cmd.Parameters.AddWithValue("@PatPhn", pat.PatPhn);
                cmd.Parameters.AddWithValue("@BloodGrp", pat.BloodGrp);
                con.Open();
                transaction = con.BeginTransaction();
                cmd.Transaction = transaction;
                int rowCount = cmd.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    transaction.Commit();
                    MessageBox.Show("Patient updated successfully!", "Success", MessageBoxButtons.OK);
                    ClearMethod();
                    
                }
                else
                {
                    MessageBox.Show("Patient Updation failed!", "Failure", MessageBoxButtons.OK);
                    ClearMethod();
                    transaction.Rollback();
                }
                con.Close();
                LoadGridView();
                ClearMethod();
            }
            else
            {
                MessageBox.Show("Please select Patient Id!", "Warning", MessageBoxButtons.OK);
            }


        }

        private void btnDelete1_Click(object sender, EventArgs e)
        {

            SqlTransaction transaction;
            if (!string.IsNullOrEmpty(textPatientId.Text))
            {
                Patient pat = new Patient();
                pat.PatId = Convert.ToInt16(textPatientId.Text);
                string sqlQuery = "DELETE FROM  PatientTbl WHERE PatId=@PatId";
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.Parameters.AddWithValue("@PatId", pat.PatId);
                con.Open();
                transaction = con.BeginTransaction();
                cmd.Transaction = transaction;
                int rowCount = cmd.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    transaction.Commit();
                    MessageBox.Show("Deleted successfully!", "Success", MessageBoxButtons.OK);
                    ClearMethod();
                    
                }
                else
                {
                    MessageBox.Show("Deletion failed!", "Failure", MessageBoxButtons.OK);
                    ClearMethod();
                    transaction.Rollback();
                }
                con.Close();
                LoadGridView();
                ClearMethod();
            }
            else
            {
                MessageBox.Show("Please select Patient Id!", "Warning", MessageBoxButtons.OK);
            }
        }

        private void pBback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home doc = new Home();
            doc.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            DOCTOR d=new DOCTOR();
            d.ShowDialog();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.Hide();
            ProjectLoading p=new ProjectLoading();
            p.ShowDialog();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            this.Hide();
            TreatMenet t=new TreatMenet();
            t.ShowDialog();
        }
    }
}
