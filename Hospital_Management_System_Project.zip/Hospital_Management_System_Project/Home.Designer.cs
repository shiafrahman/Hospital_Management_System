﻿namespace Hospital_Management_System_Project
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.pBback = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pBDiagnosis = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pBPatient = new System.Windows.Forms.PictureBox();
            this.lblDoctor = new System.Windows.Forms.Label();
            this.pBDOCTOR = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblUser = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pBback)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBDiagnosis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBPatient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBDOCTOR)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pBback
            // 
            this.pBback.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pBback.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pBback.Image = ((System.Drawing.Image)(resources.GetObject("pBback.Image")));
            this.pBback.Location = new System.Drawing.Point(1113, 12);
            this.pBback.Name = "pBback";
            this.pBback.Size = new System.Drawing.Size(65, 35);
            this.pBback.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBback.TabIndex = 15;
            this.pBback.TabStop = false;
            this.pBback.Click += new System.EventHandler(this.pBback_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(398, 483);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 34);
            this.label3.TabIndex = 14;
            this.label3.Text = "TREATMENT";
            // 
            // pBDiagnosis
            // 
            this.pBDiagnosis.BackColor = System.Drawing.Color.Transparent;
            this.pBDiagnosis.Image = ((System.Drawing.Image)(resources.GetObject("pBDiagnosis.Image")));
            this.pBDiagnosis.Location = new System.Drawing.Point(368, 351);
            this.pBDiagnosis.Name = "pBDiagnosis";
            this.pBDiagnosis.Size = new System.Drawing.Size(158, 129);
            this.pBDiagnosis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBDiagnosis.TabIndex = 13;
            this.pBDiagnosis.TabStop = false;
            this.pBDiagnosis.Click += new System.EventHandler(this.pBDiagnosis_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(509, 295);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 34);
            this.label2.TabIndex = 12;
            this.label2.Text = "PATIENT";
            // 
            // pBPatient
            // 
            this.pBPatient.BackColor = System.Drawing.Color.Transparent;
            this.pBPatient.Image = ((System.Drawing.Image)(resources.GetObject("pBPatient.Image")));
            this.pBPatient.Location = new System.Drawing.Point(473, 163);
            this.pBPatient.Name = "pBPatient";
            this.pBPatient.Size = new System.Drawing.Size(158, 129);
            this.pBPatient.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBPatient.TabIndex = 11;
            this.pBPatient.TabStop = false;
            this.pBPatient.Click += new System.EventHandler(this.pBPatient_Click);
            // 
            // lblDoctor
            // 
            this.lblDoctor.AutoSize = true;
            this.lblDoctor.BackColor = System.Drawing.Color.Transparent;
            this.lblDoctor.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDoctor.Location = new System.Drawing.Point(292, 295);
            this.lblDoctor.Name = "lblDoctor";
            this.lblDoctor.Size = new System.Drawing.Size(86, 34);
            this.lblDoctor.TabIndex = 10;
            this.lblDoctor.Text = "DOCTOR";
            // 
            // pBDOCTOR
            // 
            this.pBDOCTOR.BackColor = System.Drawing.Color.Transparent;
            this.pBDOCTOR.Image = ((System.Drawing.Image)(resources.GetObject("pBDOCTOR.Image")));
            this.pBDOCTOR.Location = new System.Drawing.Point(264, 163);
            this.pBDOCTOR.Name = "pBDOCTOR";
            this.pBDOCTOR.Size = new System.Drawing.Size(158, 129);
            this.pBDOCTOR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBDOCTOR.TabIndex = 9;
            this.pBDOCTOR.TabStop = false;
            this.pBDOCTOR.Click += new System.EventHandler(this.pBDOCTOR_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.lblUser);
            this.panel1.Controls.Add(this.pBback);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1208, 92);
            this.panel1.TabIndex = 25;
            // 
            // lblUser
            // 
            this.lblUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Britannic Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.ForeColor = System.Drawing.Color.White;
            this.lblUser.Location = new System.Drawing.Point(989, 49);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(113, 26);
            this.lblUser.TabIndex = 1;
            this.lblUser.Text = "Username";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bahnschrift Condensed", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label8.Location = new System.Drawing.Point(12, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 45);
            this.label8.TabIndex = 0;
            this.label8.Text = "HOME";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label9.Location = new System.Drawing.Point(12, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(206, 24);
            this.label9.TabIndex = 0;
            this.label9.Text = "Hospital Management System";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1208, 751);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pBDiagnosis);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pBPatient);
            this.Controls.Add(this.lblDoctor);
            this.Controls.Add(this.pBDOCTOR);
            this.Name = "Home";
            this.Text = "Home";
            this.Load += new System.EventHandler(this.Home_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pBback)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBDiagnosis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBPatient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBDOCTOR)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pBback;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pBDiagnosis;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pBPatient;
        private System.Windows.Forms.Label lblDoctor;
        private System.Windows.Forms.PictureBox pBDOCTOR;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}