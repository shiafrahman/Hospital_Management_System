﻿using Hospital_Management_System_Project.Entities;
using Hospital_Management_System_Project.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System_Project
{
    public partial class TreatMenet : Form
    {
        string conStr = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        string imgName;
        string filePath = "";
        string folderPath = @"F:\ADOproject\Hospital_Management_System_ProjectSln\Hospital_Management_System_Project\Image\";
        string imagePathFromData;
        public TreatMenet()
        {
            InitializeComponent();
        }

        private void TreatMenet_Load(object sender, EventArgs e)
        {
            lblUser.Text = Form1.userName;
            LoadDiagnosis();
            LoadCombopatient();
            LoadCombodoctor();
            pbTreatment.Image = Resources.noimage5;
            LoadGridView();
            

        }

        private void LoadDiagnosis()
        {
            string sqlQuery = "SELECT * FROM Diagnosis";
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader, LoadOption.Upsert);
            if (dt != null)
            {
                cmbDiagnosis.DisplayMember = "DiagType";
                cmbDiagnosis.ValueMember = "DiagId";
                cmbDiagnosis.DataSource = dt;
            }
            con.Close();
        }

        private void LoadCombodoctor()
        {
            string sqlQuery = "SELECT * FROM DoctorTbl";
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader, LoadOption.Upsert);
            if (dt != null)
            {
                cmbDocName.DisplayMember = "DocName";
                cmbDocName.ValueMember = "DocId";
                cmbDocName.DataSource = dt;
            }
            con.Close();
        }

        private void LoadCombopatient()
        {
            string sqlQuery = "SELECT PatId, CONCAT(FirstName, ' ', LastName) AS FullName FROM PatientTbl";
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader, LoadOption.Upsert);
            if (dt != null)
            {
                cmbPatName.DisplayMember = "FullName";
                cmbPatName.ValueMember = "PatId";
                cmbPatName.DataSource = dt;
            }
            con.Close();
        }

        private void btnAdd1_Click(object sender, EventArgs e)
        {
            SqlTransaction transaction;


            if (string.IsNullOrWhiteSpace(txtTreatmentId.Text)|| string.IsNullOrWhiteSpace(dtpVisitDate.Text)|| string.IsNullOrWhiteSpace(txtPayment.Text)|| string.IsNullOrWhiteSpace(dtpVisitDate.Text) || string.IsNullOrWhiteSpace(txtSym.Text))
            {
                MessageBox.Show("Please fill in all the required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            TREATMENT treat = new TREATMENT();
            treat.TreatmentId = Convert.ToInt16(txtTreatmentId.Text);
            treat.VisitDate = Convert.ToDateTime(dtpVisitDate.Text);
            treat.PatId = Convert.ToInt16(cmbPatName.SelectedValue);
            treat.DocId = Convert.ToInt16(cmbDocName.SelectedValue);
            treat.Symptoms = txtSym.Text;
            treat.DiagId = Convert.ToInt16(cmbDiagnosis.SelectedValue);
            treat.PaymentAmount = Convert.ToDecimal(txtPayment.Text);
            treat.isNeededNextVisit =radYes.Checked ? true : false;
            if (radYes.Checked)
            {
                treat.isNeededNextVisit = true;
            }
            else if (radNo.Checked)
            {
                treat.isNeededNextVisit = false;
            }
            else
            {
                MessageBox.Show("Please select an option for the Next Visit field.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            treat.ImagePath = folderPath + Path.GetFileName(openFileDialog1.FileName);
            string sqlQuery = "Insert INTO Treatment VALUES (@TreatmentId,@VisitDate,@PatId,@DocId,@DiagId,@Symptoms,@PaymentAmount,@isNeededNextVisit,@ImagePath)";
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            if (filePath == "")
            {
                //cmd.Parameters.AddWithValue("@ImagePath", "No Image Found");
                MessageBox.Show("Please select an image.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ImagePath",treat.ImagePath);
                try
                {
                    File.Copy(filePath, Path.Combine(folderPath, Path.GetFileName(filePath)), true);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            cmd.Parameters.AddWithValue("@TreatmentId", treat.TreatmentId);
            cmd.Parameters.AddWithValue("@VisitDate", treat.VisitDate);
            cmd.Parameters.AddWithValue("@PatId", treat.PatId);
            cmd.Parameters.AddWithValue("@DocId", treat.DocId);
            cmd.Parameters.AddWithValue("@Symptoms", treat.Symptoms);
            cmd.Parameters.AddWithValue("@DiagId", treat.DiagId);
            cmd.Parameters.AddWithValue("@PaymentAmount", treat.PaymentAmount);
            cmd.Parameters.AddWithValue("@isNeededNextVisit", treat.isNeededNextVisit);
            con.Open();
            transaction = con.BeginTransaction();
            cmd.Transaction = transaction;
            int rowCount = cmd.ExecuteNonQuery();
            if (rowCount > 0)
            {
                transaction.Commit();
                MessageBox.Show("Treatment added successfully!", "Success", MessageBoxButtons.OK);
                ClearMethod();
                
            }
            else
            {
                MessageBox.Show("Treatment Insertion failed!", "Failure", MessageBoxButtons.OK);
                ClearMethod();
                transaction.Rollback();
            }
            con.Close();
            LoadGridView();
            ClearMethod();
        }

        private void ClearMethod()
        {
            txtTreatmentId.Text = "";
            dtpVisitDate.Text = "";
            cmbPatName.SelectedValue = -1;
            cmbDocName.SelectedValue = -1;
            txtSym.Text = "";
            cmbDiagnosis.SelectedValue = -1;
            txtPayment.Text = "";
            radYes.Checked = false;
            radNo.Checked = false;
            pbTreatment.Image = Resources.noimage5;
        }

        private void LoadGridView()
        {
            ShowImageInGridView();
        }

        private void ShowImageInGridView()
        {
            string sqlQuery = "SELECT t.TreatmentId,t.VisitDate,p.FirstName+' '+p.LastName As FullName,d.DocName,t.Symptoms,dg.DiagType,t.PaymentAmount,t.IsNeededNextVisit,t.ImagePath FROM Treatment t JOIN PatientTbl p ON t.PatId=p.PatId JOIN DoctorTbl d ON t.DocId=d.DocId JOIN Diagnosis dg ON t.DiagId=dg.DiagId;";
            SqlConnection con = new SqlConnection(conStr);
            SqlDataAdapter sda = new SqlDataAdapter(sqlQuery, con);
            DataTable dt = new DataTable();
            con.Open();
            sda.Fill(dt);
            dt.Columns.Add("Picture", Type.GetType("System.Byte[]"));
            dt.Columns.Add("IsNeededNextVisitDisplay", typeof(string));
            foreach (DataRow dr in dt.Rows)
            {
                try
                {
                    dr["Picture"] = File.ReadAllBytes(dr["ImagePath"].ToString());
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                bool isNeededNextVisit = (bool)dr["IsNeededNextVisit"];
                dr["IsNeededNextVisitDisplay"] = isNeededNextVisit ? "Yes" : "No";

            }
            con.Close();
            dgvTreatment.RowTemplate.Height = 52;
            dgvTreatment.DataSource = dt;
            dgvTreatment.Columns["IsNeededNextVisit"].Visible = false;
            dgvTreatment.Columns["IsNeededNextVisitDisplay"].HeaderText = "Is Needed Next Visit?";
            DataGridViewImageColumn dgvImage = new DataGridViewImageColumn();
          
            dgvImage = (DataGridViewImageColumn)dgvTreatment.Columns[9];
            dgvImage.ImageLayout = DataGridViewImageCellLayout.Stretch;
            dgvTreatment.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void dgvTreatment_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int cellId = e.RowIndex;
            try
            {
                DataGridViewRow row = dgvTreatment.Rows[cellId];
                txtTreatmentId.Text = row.Cells[0].Value.ToString();
                dtpVisitDate.Text = row.Cells[1].Value.ToString();
                cmbPatName.Text = row.Cells[2].Value.ToString();
                cmbDocName.Text = row.Cells[3].Value.ToString();
                txtSym.Text = row.Cells[4].Value.ToString();
                cmbDiagnosis.Text = row.Cells[5].Value.ToString();
                txtPayment.Text = row.Cells[6].Value.ToString();

                string neededVisitValue = row.Cells[7].Value.ToString();
                bool r = Convert.ToBoolean(neededVisitValue);
                if (r == true)
                {
                    radYes.Checked = true;
                    radNo.Checked = false;

                }
                else
                {
                    radYes.Checked = false;
                    radNo.Checked = true;

                }

                if (imagePathFromData == "No Image")
                {
                    pbTreatment.Image = Resources.noimage5;
                }
                byte[] data = (byte[])row.Cells[9].Value;
                MemoryStream stream = new MemoryStream(data);
                pbTreatment.Image = Image.FromStream(stream);
                imagePathFromData = row.Cells[8].Value.ToString();
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home doc = new Home();
            doc.Show();
        }

        private void btnTrmBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image File(*.jpg; *.png; *.jpeg; *.gif; *.bmp)| *.jpg; *.png; *.jpeg; *.gif; *.bmp|all files|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                imgName = openFileDialog1.SafeFileName;
                pbTreatment.Image = new Bitmap(openFileDialog1.FileName);
                filePath = openFileDialog1.FileName;
            }
        }

        private void btnPatClear_Click(object sender, EventArgs e)
        {
            ClearMethod();
        }

        private void btnUpdate1_Click(object sender, EventArgs e)
        {
            SqlTransaction transaction;
            if (!string.IsNullOrEmpty(txtTreatmentId.Text))
            {
                TREATMENT treat = new TREATMENT();
                treat.TreatmentId = Convert.ToInt16(txtTreatmentId.Text);
                treat.VisitDate = Convert.ToDateTime(dtpVisitDate.Text);
                treat.PatId = Convert.ToInt16(cmbPatName.SelectedValue);
                treat.DocId = Convert.ToInt16(cmbDocName.SelectedValue);
                treat.Symptoms = txtSym.Text;
                treat.DiagId = Convert.ToInt16(cmbDiagnosis.SelectedValue);
                treat.PaymentAmount = Convert.ToDecimal(txtPayment.Text);
                treat.isNeededNextVisit = radYes.Checked ? true : false;
                treat.ImagePath = folderPath + Path.GetFileName(openFileDialog1.FileName);
                string sqlQuery = "UPDATE Treatment SET VisitDate=@VisitDate,PatId=@PatId,DocId=@DocId,DiagId=@DiagId,Symptoms=@Symptoms,PaymentAmount=@PaymentAmount,isNeededNextVisit=@isNeededNextVisit,ImagePath=@ImagePath WHERE TreatmentId=@TreatmentId";

                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                if (filePath == "")
                {
                    cmd.Parameters.AddWithValue("@ImagePath", imagePathFromData);
                }
                else
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@ImagePath",treat.ImagePath);
                    try
                    {
                        File.Copy(filePath, Path.Combine(folderPath, Path.GetFileName(filePath)), true);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                cmd.Parameters.AddWithValue("@TreatmentId", treat.TreatmentId);
                cmd.Parameters.AddWithValue("@VisitDate", treat.VisitDate);
                cmd.Parameters.AddWithValue("@PatId", treat.PatId);
                cmd.Parameters.AddWithValue("@DocId", treat.DocId);
                cmd.Parameters.AddWithValue("@Symptoms", treat.Symptoms);
                cmd.Parameters.AddWithValue("@DiagId", treat.DiagId);
                cmd.Parameters.AddWithValue("@PaymentAmount", treat.PaymentAmount);
                cmd.Parameters.AddWithValue("@isNeededNextVisit", treat.isNeededNextVisit);
                con.Open();
                transaction = con.BeginTransaction();
                cmd.Transaction = transaction;
                
                int rowCount = cmd.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    transaction.Commit();
                    MessageBox.Show("Treatment Updated successfully!", "Success", MessageBoxButtons.OK);
                    ClearMethod();
                   
                }
                else
                {
                    MessageBox.Show("Treatment Updation failed!", "Failure", MessageBoxButtons.OK);
                    ClearMethod();
                    transaction.Rollback();
                }
                con.Close();
                LoadGridView();
                ClearMethod(); ;
            }
            else
            {
                MessageBox.Show("Please select Treatment Id!", "Warning", MessageBoxButtons.OK);
            }
        }

        private void btnDelete1_Click(object sender, EventArgs e)
        {
            SqlTransaction transaction;
            if (!string.IsNullOrEmpty(txtTreatmentId.Text))
            {
                TREATMENT treat = new TREATMENT();
                treat.TreatmentId = Convert.ToInt16(txtTreatmentId.Text);
                string sqlQuery = "DELETE FROM  Treatment WHERE TreatmentId=@TreatmentId";
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.Parameters.AddWithValue("@TreatmentId", treat.TreatmentId);
                con.Open();
                transaction = con.BeginTransaction();
               
                cmd.Transaction = transaction;
                int rowCount = cmd.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    transaction.Commit();
                    MessageBox.Show("Deleted successfully!", "Success", MessageBoxButtons.OK);
                    ClearMethod();
                    
                }
                else
                {
                    MessageBox.Show("Deletion failed!", "Failure", MessageBoxButtons.OK);
                    ClearMethod();
                    transaction.Rollback();
                }
                con.Close();
                LoadGridView();
                ClearMethod();
            }
            else
            {
                MessageBox.Show("Please select Purchase Id!", "Warning", MessageBoxButtons.OK);
            }
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            List<TreatmentViewModel> list = new List<TreatmentViewModel>();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                string SqlQuery = "SELECT t.TreatmentId,t.PatId,t.DocId,t.DiagId,t.VisitDate,p.FirstName+' '+p.LastName As FullName,d.DocName,t.Symptoms,dg.DiagType,t.PaymentAmount,t.IsNeededNextVisit,t.ImagePath FROM Treatment t JOIN PatientTbl p ON t.PatId=p.PatId JOIN DoctorTbl d ON t.DocId=d.DocId JOIN Diagnosis dg ON t.DiagId=dg.DiagId;";


                
                SqlDataAdapter sda = new SqlDataAdapter(SqlQuery, con);
                DataTable dt = new DataTable();
                con.Open();
                sda.Fill(dt);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    TreatmentViewModel objPurchase = new TreatmentViewModel();
                    objPurchase.TreatmentId = Convert.ToInt32(dt.Rows[i]["TreatmentId"].ToString());
                    objPurchase.PatId = Convert.ToInt32(dt.Rows[i]["PatId"].ToString());
                    objPurchase.DocId = Convert.ToInt32(dt.Rows[i]["DocId"].ToString());
                    objPurchase.DiagId = Convert.ToInt32(dt.Rows[i]["DiagId"].ToString());
                    objPurchase.VisitDate = Convert.ToDateTime(dt.Rows[i]["VisitDate"].ToString());
                    objPurchase.FirstName = dt.Rows[i]["FullName"].ToString();
                    objPurchase.PaymentAmount = Convert.ToDecimal(dt.Rows[i]["PaymentAmount"].ToString());
                    objPurchase.DocName = dt.Rows[i]["DocName"].ToString();
                    objPurchase.Symptoms = dt.Rows[i]["Symptoms"].ToString();
                    objPurchase.DiagType = dt.Rows[i]["DiagType"].ToString();
                    objPurchase.ImagePath = dt.Rows[i]["ImagePath"].ToString();
                    objPurchase.isNeededNextVisit = Convert.ToBoolean(dt.Rows[i]["IsNeededNextVisit"].ToString());
                    list.Add(objPurchase);
                }
            }
            using (Report form = new Report(list))
            {
                form.ShowDialog();
            }
        }

        private void btnAddDiagnosis_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtDiag.Text) == true)
            {
                txtDiag.Focus();
                errorProvider1.SetError(this.txtDiag, "Please Enter productName");
                ClearMethod();
            }
            else
            {
                Diagnosis objProduct = new Diagnosis();
                objProduct.DiagType = txtDiag.Text;
                string sqlQuery = "Insert INTO Diagnosis (DiagType) VALUES ('" + objProduct.DiagType + "')";
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                con.Open();
                int rowCount = cmd.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    MessageBox.Show("Diagnosis added successfully!", "Success", MessageBoxButtons.OK);
                    //ClearMethod();
                }
                else
                {
                    MessageBox.Show("Diagnosis Insertion failed!", "Failure", MessageBoxButtons.OK);
                    //ClearMethod();
                }
                con.Close();
                LoadDiagnosis();
        
            }   
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Hide();
            DOCTOR d= new DOCTOR();
            d.ShowDialog();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Hide();
            PATIENT d = new PATIENT();
            d.ShowDialog();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            this.Hide();
            ProjectLoading p=new ProjectLoading();
            p.ShowDialog();
        }
    }
}
