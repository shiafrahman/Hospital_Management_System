﻿namespace Hospital_Management_System_Project
{
    partial class PATIENT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PATIENT));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pBback = new System.Windows.Forms.PictureBox();
            this.lblUser = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPatClear = new System.Windows.Forms.Button();
            this.btnPatBrowse = new System.Windows.Forms.Button();
            this.pbPatient = new System.Windows.Forms.PictureBox();
            this.btnDelete1 = new System.Windows.Forms.Button();
            this.btnUpdate1 = new System.Windows.Forms.Button();
            this.btnAdd1 = new System.Windows.Forms.Button();
            this.lblPatientBlood = new System.Windows.Forms.Label();
            this.cmbBloodGroup = new System.Windows.Forms.ComboBox();
            this.lblPatientDOB = new System.Windows.Forms.Label();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.lblPatientGender = new System.Windows.Forms.Label();
            this.cmbPatientGender = new System.Windows.Forms.ComboBox();
            this.lblPatientAge = new System.Windows.Forms.Label();
            this.txtPatAge = new System.Windows.Forms.TextBox();
            this.lblPatientPhn = new System.Windows.Forms.Label();
            this.txtPhnNo = new System.Windows.Forms.TextBox();
            this.lblPAddress = new System.Windows.Forms.Label();
            this.txtPatientAddress = new System.Windows.Forms.TextBox();
            this.lblPatientFName = new System.Windows.Forms.Label();
            this.txtPatientFName = new System.Windows.Forms.TextBox();
            this.lblPatientId = new System.Windows.Forms.Label();
            this.textPatientId = new System.Windows.Forms.TextBox();
            this.txtPatientLName = new System.Windows.Forms.TextBox();
            this.lalPLName = new System.Windows.Forms.Label();
            this.dgvParient = new System.Windows.Forms.DataGridView();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBback)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPatient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParient)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.pBback);
            this.panel2.Controls.Add(this.lblUser);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1594, 92);
            this.panel2.TabIndex = 19;
            // 
            // pBback
            // 
            this.pBback.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pBback.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.pBback.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBback.Image = ((System.Drawing.Image)(resources.GetObject("pBback.Image")));
            this.pBback.Location = new System.Drawing.Point(1406, 9);
            this.pBback.Name = "pBback";
            this.pBback.Size = new System.Drawing.Size(53, 28);
            this.pBback.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBback.TabIndex = 22;
            this.pBback.TabStop = false;
            this.pBback.Click += new System.EventHandler(this.pBback_Click);
            // 
            // lblUser
            // 
            this.lblUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Britannic Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.ForeColor = System.Drawing.Color.White;
            this.lblUser.Location = new System.Drawing.Point(1256, 11);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(113, 26);
            this.lblUser.TabIndex = 1;
            this.lblUser.Text = "Username";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift Condensed", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Location = new System.Drawing.Point(23, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(191, 45);
            this.label2.TabIndex = 0;
            this.label2.Text = "PATIENT FORM";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(206, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hospital Management System";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPatClear
            // 
            this.btnPatClear.BackColor = System.Drawing.Color.Transparent;
            this.btnPatClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPatClear.Font = new System.Drawing.Font("Berlin Sans FB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPatClear.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnPatClear.Location = new System.Drawing.Point(1242, 281);
            this.btnPatClear.Name = "btnPatClear";
            this.btnPatClear.Size = new System.Drawing.Size(127, 51);
            this.btnPatClear.TabIndex = 62;
            this.btnPatClear.Text = "Clear";
            this.btnPatClear.UseVisualStyleBackColor = false;
            this.btnPatClear.Click += new System.EventHandler(this.btnPatClear_Click);
            // 
            // btnPatBrowse
            // 
            this.btnPatBrowse.BackColor = System.Drawing.Color.Transparent;
            this.btnPatBrowse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPatBrowse.Font = new System.Drawing.Font("Berlin Sans FB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPatBrowse.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnPatBrowse.Location = new System.Drawing.Point(1051, 298);
            this.btnPatBrowse.Name = "btnPatBrowse";
            this.btnPatBrowse.Size = new System.Drawing.Size(111, 40);
            this.btnPatBrowse.TabIndex = 61;
            this.btnPatBrowse.Text = "Browse";
            this.btnPatBrowse.UseVisualStyleBackColor = false;
            this.btnPatBrowse.Click += new System.EventHandler(this.btnPatBrowse_Click);
            // 
            // pbPatient
            // 
            this.pbPatient.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbPatient.Location = new System.Drawing.Point(1002, 114);
            this.pbPatient.Name = "pbPatient";
            this.pbPatient.Size = new System.Drawing.Size(187, 168);
            this.pbPatient.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPatient.TabIndex = 60;
            this.pbPatient.TabStop = false;
            // 
            // btnDelete1
            // 
            this.btnDelete1.BackColor = System.Drawing.Color.Transparent;
            this.btnDelete1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete1.Font = new System.Drawing.Font("Berlin Sans FB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnDelete1.Location = new System.Drawing.Point(1242, 224);
            this.btnDelete1.Name = "btnDelete1";
            this.btnDelete1.Size = new System.Drawing.Size(127, 51);
            this.btnDelete1.TabIndex = 58;
            this.btnDelete1.Text = "Delete";
            this.btnDelete1.UseVisualStyleBackColor = false;
            this.btnDelete1.Click += new System.EventHandler(this.btnDelete1_Click);
            // 
            // btnUpdate1
            // 
            this.btnUpdate1.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdate1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate1.Font = new System.Drawing.Font("Berlin Sans FB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnUpdate1.Location = new System.Drawing.Point(1242, 168);
            this.btnUpdate1.Name = "btnUpdate1";
            this.btnUpdate1.Size = new System.Drawing.Size(127, 51);
            this.btnUpdate1.TabIndex = 57;
            this.btnUpdate1.Text = "Update";
            this.btnUpdate1.UseVisualStyleBackColor = false;
            this.btnUpdate1.Click += new System.EventHandler(this.btnUpdate1_Click);
            // 
            // btnAdd1
            // 
            this.btnAdd1.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd1.Font = new System.Drawing.Font("Berlin Sans FB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAdd1.Location = new System.Drawing.Point(1242, 111);
            this.btnAdd1.Name = "btnAdd1";
            this.btnAdd1.Size = new System.Drawing.Size(127, 51);
            this.btnAdd1.TabIndex = 56;
            this.btnAdd1.Text = "Add";
            this.btnAdd1.UseVisualStyleBackColor = false;
            this.btnAdd1.Click += new System.EventHandler(this.btnAdd1_Click);
            // 
            // lblPatientBlood
            // 
            this.lblPatientBlood.AutoSize = true;
            this.lblPatientBlood.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientBlood.ForeColor = System.Drawing.Color.GhostWhite;
            this.lblPatientBlood.Location = new System.Drawing.Point(546, 241);
            this.lblPatientBlood.Name = "lblPatientBlood";
            this.lblPatientBlood.Size = new System.Drawing.Size(137, 34);
            this.lblPatientBlood.TabIndex = 53;
            this.lblPatientBlood.Text = "Blood Group :";
            // 
            // cmbBloodGroup
            // 
            this.cmbBloodGroup.BackColor = System.Drawing.Color.GhostWhite;
            this.cmbBloodGroup.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBloodGroup.ForeColor = System.Drawing.Color.Black;
            this.cmbBloodGroup.FormattingEnabled = true;
            this.cmbBloodGroup.Items.AddRange(new object[] {
            "A+",
            "O+",
            "AB+",
            "B+",
            "A-",
            "O-",
            "AB-",
            "B-"});
            this.cmbBloodGroup.Location = new System.Drawing.Point(726, 242);
            this.cmbBloodGroup.Name = "cmbBloodGroup";
            this.cmbBloodGroup.Size = new System.Drawing.Size(236, 36);
            this.cmbBloodGroup.TabIndex = 52;
            this.cmbBloodGroup.Text = "Blood Group";
            // 
            // lblPatientDOB
            // 
            this.lblPatientDOB.AutoSize = true;
            this.lblPatientDOB.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientDOB.ForeColor = System.Drawing.Color.White;
            this.lblPatientDOB.Location = new System.Drawing.Point(57, 260);
            this.lblPatientDOB.Name = "lblPatientDOB";
            this.lblPatientDOB.Size = new System.Drawing.Size(143, 34);
            this.lblPatientDOB.TabIndex = 51;
            this.lblPatientDOB.Text = "Date of Birth :";
            // 
            // dtpDOB
            // 
            this.dtpDOB.CalendarFont = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDOB.CalendarTitleBackColor = System.Drawing.Color.Snow;
            this.dtpDOB.Location = new System.Drawing.Point(238, 272);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(236, 22);
            this.dtpDOB.TabIndex = 50;
            // 
            // lblPatientGender
            // 
            this.lblPatientGender.AutoSize = true;
            this.lblPatientGender.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientGender.ForeColor = System.Drawing.Color.GhostWhite;
            this.lblPatientGender.Location = new System.Drawing.Point(591, 116);
            this.lblPatientGender.Name = "lblPatientGender";
            this.lblPatientGender.Size = new System.Drawing.Size(92, 34);
            this.lblPatientGender.TabIndex = 49;
            this.lblPatientGender.Text = "Gender :";
            // 
            // cmbPatientGender
            // 
            this.cmbPatientGender.BackColor = System.Drawing.Color.GhostWhite;
            this.cmbPatientGender.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPatientGender.ForeColor = System.Drawing.Color.Black;
            this.cmbPatientGender.FormattingEnabled = true;
            this.cmbPatientGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmbPatientGender.Location = new System.Drawing.Point(726, 118);
            this.cmbPatientGender.Name = "cmbPatientGender";
            this.cmbPatientGender.Size = new System.Drawing.Size(236, 36);
            this.cmbPatientGender.TabIndex = 48;
            this.cmbPatientGender.Text = "Gender";
            // 
            // lblPatientAge
            // 
            this.lblPatientAge.AutoSize = true;
            this.lblPatientAge.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientAge.ForeColor = System.Drawing.Color.White;
            this.lblPatientAge.Location = new System.Drawing.Point(69, 223);
            this.lblPatientAge.Name = "lblPatientAge";
            this.lblPatientAge.Size = new System.Drawing.Size(131, 34);
            this.lblPatientAge.TabIndex = 47;
            this.lblPatientAge.Text = "Patient Age :";
            // 
            // txtPatAge
            // 
            this.txtPatAge.BackColor = System.Drawing.Color.White;
            this.txtPatAge.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPatAge.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPatAge.ForeColor = System.Drawing.Color.Black;
            this.txtPatAge.Location = new System.Drawing.Point(238, 227);
            this.txtPatAge.Multiline = true;
            this.txtPatAge.Name = "txtPatAge";
            this.txtPatAge.Size = new System.Drawing.Size(236, 30);
            this.txtPatAge.TabIndex = 46;
            // 
            // lblPatientPhn
            // 
            this.lblPatientPhn.AutoSize = true;
            this.lblPatientPhn.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientPhn.ForeColor = System.Drawing.Color.GhostWhite;
            this.lblPatientPhn.Location = new System.Drawing.Point(570, 199);
            this.lblPatientPhn.Name = "lblPatientPhn";
            this.lblPatientPhn.Size = new System.Drawing.Size(113, 34);
            this.lblPatientPhn.TabIndex = 45;
            this.lblPatientPhn.Text = "Phone No :";
            // 
            // txtPhnNo
            // 
            this.txtPhnNo.BackColor = System.Drawing.Color.GhostWhite;
            this.txtPhnNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPhnNo.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhnNo.ForeColor = System.Drawing.Color.Black;
            this.txtPhnNo.Location = new System.Drawing.Point(726, 203);
            this.txtPhnNo.Multiline = true;
            this.txtPhnNo.Name = "txtPhnNo";
            this.txtPhnNo.Size = new System.Drawing.Size(236, 30);
            this.txtPhnNo.TabIndex = 44;
            // 
            // lblPAddress
            // 
            this.lblPAddress.AutoSize = true;
            this.lblPAddress.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPAddress.ForeColor = System.Drawing.Color.GhostWhite;
            this.lblPAddress.Location = new System.Drawing.Point(512, 152);
            this.lblPAddress.Name = "lblPAddress";
            this.lblPAddress.Size = new System.Drawing.Size(171, 34);
            this.lblPAddress.TabIndex = 43;
            this.lblPAddress.Text = "Patient Address :";
            // 
            // txtPatientAddress
            // 
            this.txtPatientAddress.BackColor = System.Drawing.Color.White;
            this.txtPatientAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPatientAddress.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPatientAddress.ForeColor = System.Drawing.Color.Black;
            this.txtPatientAddress.Location = new System.Drawing.Point(726, 160);
            this.txtPatientAddress.Multiline = true;
            this.txtPatientAddress.Name = "txtPatientAddress";
            this.txtPatientAddress.Size = new System.Drawing.Size(236, 34);
            this.txtPatientAddress.TabIndex = 42;
            // 
            // lblPatientFName
            // 
            this.lblPatientFName.AutoSize = true;
            this.lblPatientFName.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientFName.ForeColor = System.Drawing.Color.White;
            this.lblPatientFName.Location = new System.Drawing.Point(74, 150);
            this.lblPatientFName.Name = "lblPatientFName";
            this.lblPatientFName.Size = new System.Drawing.Size(126, 34);
            this.lblPatientFName.TabIndex = 41;
            this.lblPatientFName.Text = "First Name :";
            // 
            // txtPatientFName
            // 
            this.txtPatientFName.BackColor = System.Drawing.Color.White;
            this.txtPatientFName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPatientFName.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPatientFName.ForeColor = System.Drawing.Color.Black;
            this.txtPatientFName.Location = new System.Drawing.Point(238, 154);
            this.txtPatientFName.Multiline = true;
            this.txtPatientFName.Name = "txtPatientFName";
            this.txtPatientFName.Size = new System.Drawing.Size(236, 30);
            this.txtPatientFName.TabIndex = 40;
            // 
            // lblPatientId
            // 
            this.lblPatientId.AutoSize = true;
            this.lblPatientId.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientId.ForeColor = System.Drawing.Color.White;
            this.lblPatientId.Location = new System.Drawing.Point(87, 114);
            this.lblPatientId.Name = "lblPatientId";
            this.lblPatientId.Size = new System.Drawing.Size(113, 34);
            this.lblPatientId.TabIndex = 39;
            this.lblPatientId.Text = "Patient Id :";
            // 
            // textPatientId
            // 
            this.textPatientId.BackColor = System.Drawing.Color.White;
            this.textPatientId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textPatientId.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textPatientId.ForeColor = System.Drawing.Color.Black;
            this.textPatientId.Location = new System.Drawing.Point(238, 118);
            this.textPatientId.Multiline = true;
            this.textPatientId.Name = "textPatientId";
            this.textPatientId.Size = new System.Drawing.Size(236, 30);
            this.textPatientId.TabIndex = 38;
            // 
            // txtPatientLName
            // 
            this.txtPatientLName.BackColor = System.Drawing.Color.White;
            this.txtPatientLName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPatientLName.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPatientLName.ForeColor = System.Drawing.Color.Black;
            this.txtPatientLName.Location = new System.Drawing.Point(238, 190);
            this.txtPatientLName.Multiline = true;
            this.txtPatientLName.Name = "txtPatientLName";
            this.txtPatientLName.Size = new System.Drawing.Size(236, 30);
            this.txtPatientLName.TabIndex = 40;
            // 
            // lalPLName
            // 
            this.lalPLName.AutoSize = true;
            this.lalPLName.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lalPLName.ForeColor = System.Drawing.Color.White;
            this.lalPLName.Location = new System.Drawing.Point(78, 188);
            this.lalPLName.Name = "lalPLName";
            this.lalPLName.Size = new System.Drawing.Size(122, 34);
            this.lalPLName.TabIndex = 41;
            this.lalPLName.Text = "Last Name :";
            // 
            // dgvParient
            // 
            this.dgvParient.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvParient.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Bahnschrift", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.Padding = new System.Windows.Forms.Padding(10);
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParient.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvParient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvParient.Location = new System.Drawing.Point(80, 422);
            this.dgvParient.Name = "dgvParient";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.Padding = new System.Windows.Forms.Padding(10);
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvParient.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvParient.RowHeadersWidth = 51;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Bahnschrift SemiLight", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.Format = "D";
            dataGridViewCellStyle9.NullValue = null;
            this.dgvParient.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvParient.RowTemplate.Height = 24;
            this.dgvParient.Size = new System.Drawing.Size(1355, 357);
            this.dgvParient.TabIndex = 63;
            this.dgvParient.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvParient_CellClick);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Location = new System.Drawing.Point(629, 383);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(189, 36);
            this.label3.TabIndex = 23;
            this.label3.Text = "PATIENT TABLE";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Britannic Bold", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(653, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 22);
            this.label4.TabIndex = 23;
            this.label4.Text = "Add Doctor";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Britannic Bold", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(572, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 22);
            this.label5.TabIndex = 24;
            this.label5.Text = "Home";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Britannic Bold", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(779, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 22);
            this.label6.TabIndex = 25;
            this.label6.Text = "Add Treatment";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // PATIENT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1594, 814);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgvParient);
            this.Controls.Add(this.btnPatClear);
            this.Controls.Add(this.btnPatBrowse);
            this.Controls.Add(this.pbPatient);
            this.Controls.Add(this.btnDelete1);
            this.Controls.Add(this.btnUpdate1);
            this.Controls.Add(this.btnAdd1);
            this.Controls.Add(this.lblPatientBlood);
            this.Controls.Add(this.cmbBloodGroup);
            this.Controls.Add(this.lblPatientDOB);
            this.Controls.Add(this.dtpDOB);
            this.Controls.Add(this.lblPatientGender);
            this.Controls.Add(this.cmbPatientGender);
            this.Controls.Add(this.lblPatientAge);
            this.Controls.Add(this.txtPatAge);
            this.Controls.Add(this.lblPatientPhn);
            this.Controls.Add(this.txtPhnNo);
            this.Controls.Add(this.lblPAddress);
            this.Controls.Add(this.txtPatientAddress);
            this.Controls.Add(this.lalPLName);
            this.Controls.Add(this.lblPatientFName);
            this.Controls.Add(this.txtPatientLName);
            this.Controls.Add(this.txtPatientFName);
            this.Controls.Add(this.lblPatientId);
            this.Controls.Add(this.textPatientId);
            this.Controls.Add(this.panel2);
            this.Name = "PATIENT";
            this.Text = "PATIENT";
            this.Load += new System.EventHandler(this.PATIENT_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBback)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPatient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParient)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pBback;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPatClear;
        private System.Windows.Forms.Button btnPatBrowse;
        private System.Windows.Forms.PictureBox pbPatient;
        private System.Windows.Forms.Button btnDelete1;
        private System.Windows.Forms.Button btnUpdate1;
        private System.Windows.Forms.Button btnAdd1;
        private System.Windows.Forms.Label lblPatientBlood;
        private System.Windows.Forms.ComboBox cmbBloodGroup;
        private System.Windows.Forms.Label lblPatientDOB;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.Label lblPatientGender;
        private System.Windows.Forms.ComboBox cmbPatientGender;
        private System.Windows.Forms.Label lblPatientAge;
        private System.Windows.Forms.TextBox txtPatAge;
        private System.Windows.Forms.Label lblPatientPhn;
        private System.Windows.Forms.TextBox txtPhnNo;
        private System.Windows.Forms.Label lblPAddress;
        private System.Windows.Forms.TextBox txtPatientAddress;
        private System.Windows.Forms.Label lblPatientFName;
        private System.Windows.Forms.TextBox txtPatientFName;
        private System.Windows.Forms.Label lblPatientId;
        private System.Windows.Forms.TextBox textPatientId;
        private System.Windows.Forms.TextBox txtPatientLName;
        private System.Windows.Forms.Label lalPLName;
        private System.Windows.Forms.DataGridView dgvParient;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}