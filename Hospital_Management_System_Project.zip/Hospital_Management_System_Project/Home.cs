﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System_Project
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void pBback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 user = new Form1();
            user.Show();
        }

        private void pBDOCTOR_Click(object sender, EventArgs e)
        {
            this.Hide();
            DOCTOR doc=new DOCTOR();
            doc.Show();
        }

        private void pBPatient_Click(object sender, EventArgs e)
        {
            this.Hide();
            PATIENT pat = new PATIENT();
            pat.Show();
        }

        private void pBDiagnosis_Click(object sender, EventArgs e)
        {
            this.Hide();
            TreatMenet pat = new TreatMenet();
            pat.Show();
        }

        private void Home_Load(object sender, EventArgs e)
        {
            lblUser.Text = Form1.userName;
        }
    }
}
